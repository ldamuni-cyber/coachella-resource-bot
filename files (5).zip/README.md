# 🌵 Coachella Resource Bot

**An AI-powered festival planning assistant built with LangChain and Google Gemini.**

> 🚀 **[Live Demo on Hugging Face Spaces](#)** *(link to be added after deployment)*

---

## Overview

The Coachella Resource Bot is a multi-tool LangChain chatbot that helps festival-goers plan their Coachella 2025 experience. It can look up artist schedules, recommend artists based on your music taste, estimate your trip budget, and answer logistics questions — all in a single conversational interface.

**Who it's for:** First-time Coachella attendees and returning festivalgoers who want a faster, smarter way to plan — instead of cross-referencing four different tabs.

---

## The Problem

Festivals like Coachella are overwhelming to navigate. The lineup has 150+ artists, the schedule spans three days across seven stages, and the logistics (tickets, travel, camping, food, packing) require hours of research across Reddit threads, the official app, and spreadsheets. I've seen people share weekend spending breakdowns that were clearly unplanned and unrealistic — and I've experienced the same anxiety at smaller festivals. This bot brings all of that research into one place.

---

## How It Works

The bot uses a **LangChain tool-calling agent** (with Gemini 1.5 Flash as the LLM) that routes each user message to the appropriate tool based on intent.

```
User Message
     │
     ▼
  LangChain Agent (Gemini 1.5 Flash)
     │
     ├──► 🎵 lookup_artist_schedule   → CSV database of Coachella 2025 artists
     ├──► 🎯 recommend_artists        → Genre-matching logic across the lineup
     ├──► 💰 estimate_budget          → Budget CSV with low/mid/high cost tiers
     └──► 📖 get_festival_tips        → RAG over a Markdown knowledge base
```

### Tools

| Tool | Trigger | Data Source |
|------|---------|-------------|
| `lookup_artist_schedule` | "What time does X perform?", "Show me the Friday lineup" | `data/artists.csv` |
| `recommend_artists` | "I like hip-hop, who should I see?", "Recommend me some artists" | `data/artists.csv` + genre mapping |
| `estimate_budget` | "How much will this cost?", "Estimate my budget" | `data/budget_items.csv` |
| `get_festival_tips` | "What should I pack?", "Camping tips?", "How do I get there?" | `data/festival_tips.md` (RAG) |

The agent can chain tools together — e.g., a user asking *"I like indie music and I'm on a budget, what should I plan for?"* will trigger `recommend_artists` and `estimate_budget` in sequence.

---

## Sample Conversations

### 1. Artist Schedule Lookup
```
User: What time does Lady Gaga perform?

Bot: 🎵 Lady Gaga ⭐ HEADLINER
     📅 Friday | ⏰ 10:00 PM – 11:30 PM
     🏟️  Main Stage | 🎶 Pop/Electronic

     She's closing out Friday night! 🌟 Want me to find other acts 
     before her so you can plan your evening?
```

### 2. Artist Recommendations
```
User: I love indie and electronic music — who should I see?

Bot: Based on your taste for indie, electronic, here are my picks:

     🎵 Charli XCX — Pop/Electronic
        Friday, 8:30 PM at Sahara

     🎵 Vampire Weekend — Indie Rock
        Saturday, 7:00 PM at Outdoor Theatre

     🎵 Four Tet — Electronic
        Friday, 11:00 PM at Sahara

     🎵 Clairo — Indie Pop
        Sunday, 6:30 PM at Outdoor Theatre

     💡 Tip: Use the schedule lookup to get full details on any of these!
```

### 3. Budget Estimation
```
User: I'm flying in from Chicago, doing tent camping, and I'm on a budget.

Bot: Budget Budget Estimate for Coachella 2025

     Item                           Est. Cost
     ──────────────────────────────────────────
     🎟️  Ticket                        $549
     🏕️  Accommodation                  $125
     ✈️  Travel                         $150
     🍔 Food & Drink (3 days)           $165
     🧴 Extras & Supplies               $15
     ──────────────────────────────────────────
     💰 ESTIMATED TOTAL                $1,004

     📌 This is a budget estimate. Book early for the best prices!
```

### 4. Festival Tips
```
User: What should I pack? It's my first time.

Bot: 📖 Festival Tips: What to Bring

     Must-have items:
     - Reusable water bottle (refill stations are free)
     - Sunscreen (SPF 50+) — the desert sun is brutal
     - Comfortable, broken-in shoes — you walk 5-10 miles per day
     - Light layers — 95°F days and 55°F nights
     - Portable phone charger / power bank
     ...
```

---

## Key Findings / What I Learned

Building this bot taught me how much **prompt engineering and tool design matter more than model choice**. Early on, the agent would use the wrong tool for vague queries — I fixed this by writing highly specific docstrings for each tool, since LangChain uses the docstring to decide when to call it. This was the single biggest quality improvement I made.

The **budget tool** was harder than expected. I started with a simple flat-rate calculator but realized users describe trips in natural language ("I'm flying in, budget trip, tent camping") not in structured fields. Parsing intent from prose required thinking carefully about keyword matching and fallback logic.

If I were to rebuild this, I'd use a **proper vector database** (like Chroma or FAISS) for the festival tips RAG instead of simple string matching — it would handle synonyms and paraphrased questions much better. I'd also add a **real-time setlist/schedule API** so the data stays current beyond 2025.

---

## Who Would Care

Festival attendees planning Coachella — especially first-timers who don't know where to start. Event promoters could adapt this architecture for any festival (Lollapalooza, CMA Fest, Bonnaroo) by swapping in a different lineup CSV and knowledge base. Travel bloggers and influencers who cover festivals might use a version of this to answer reader questions automatically. The budget estimation feature is particularly useful for younger attendees trying to make the math work on a real salary.

---

## How to Run

### Local Setup

```bash
# 1. Clone the repo
git clone https://github.com/ldamuni-cyber/coachella-resource-bot.git
cd coachella-resource-bot

# 2. Create and activate a virtual environment
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate

# 3. Install dependencies
pip install -r requirements.txt

# 4. Set up your API key
cp .env.example .env
# Edit .env and add your GOOGLE_API_KEY
# Get a free key at: https://aistudio.google.com

# 5. Launch the app
python app.py
```

Open your browser to `http://localhost:7860`

### Get a Free API Key (Gemini)

1. Go to [Google AI Studio](https://aistudio.google.com)
2. Click **Get API Key** → **Create API key**
3. Copy the key into your `.env` file

### Deploy to Hugging Face Spaces

1. Create a new Space at [huggingface.co/spaces](https://huggingface.co/spaces)
2. Select **Gradio** as the SDK
3. Push this repo to the Space
4. Add `GOOGLE_API_KEY` as a Secret in Space Settings

---

## Project Structure

```
coachella-resource-bot/
├── app.py                  # Main application (LangChain agent + Gradio UI)
├── requirements.txt        # Python dependencies
├── .env.example            # API key template
├── .gitignore
├── README.md
├── data/
│   ├── artists.csv         # Coachella 2025 lineup with schedule data
│   ├── budget_items.csv    # Cost estimates (low/mid/high tiers)
│   └── festival_tips.md    # Knowledge base for RAG (logistics, tips)
└── logs/                   # Auto-generated conversation logs (gitignored)
```

---

## Tech Stack

- **LangChain** — Agent orchestration and tool routing
- **Google Gemini 1.5 Flash** — LLM (free tier available)
- **Gradio** — Chat interface
- **Python** — Core language
- **CSV + Markdown** — Lightweight data sources (no database required)

---

*Built as a portfolio project for CS 444. Data is representative of Coachella 2025.*
